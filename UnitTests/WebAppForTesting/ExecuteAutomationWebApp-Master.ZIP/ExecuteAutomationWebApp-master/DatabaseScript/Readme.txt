EAEmployeeApp_Windows_Web_DatabaseScript
**************************************

This script can just be executed on SQL Server Management studio to create EmployeeDB used by the Application