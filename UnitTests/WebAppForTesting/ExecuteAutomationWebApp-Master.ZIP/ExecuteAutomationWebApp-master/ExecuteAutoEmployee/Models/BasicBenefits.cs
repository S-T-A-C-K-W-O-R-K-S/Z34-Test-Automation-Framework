﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ExecuteAutoEmployee.Models
{
    public class BasicBenefits
    {
        public int Id { get; set; }
        public string BenefitName { get; set; }
    }
}